const jwt = require('jsonwebtoken');

function verifyToken(req, res, next) {
	const authHeader = req.headers.authorization;
	if (!authHeader || !authHeader.startsWith('Bearer ')) return res.status(401).json({message: 'Brak lub niepoprawny token autoryzacji.'});

	const token = authHeader.split(' ')[1];
	try {
		const decoded = jwt.verify(token, process.env.JWT_SECRET, {algorithm: 'HS512'});
		req.user = {id: decoded.id, role: decoded.role};
		next();
	} catch (err) {
		return res.status(401).json({message: 'Niepoprawny lub wygasły token.'});
	}
}

module.exports = {verifyToken};